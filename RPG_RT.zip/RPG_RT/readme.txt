Target file name is "RPG_RT.exe". There are 4 types per update.


en_im\RPG_RT.exe
VirusTotal:
https://www.virustotal.com/gui/file/2c50880c9a6fe30ca50d250a371d52d931e41c124b7a138f0b041cbe45713523/detection

en_pf\RPG_RT.exe
VirusTotal:
https://www.virustotal.com/gui/file/eb16aebfe5b2be7e8f922eb0db2573760e05ad9311c62818af9b85a3e7005434/detection

jp_im\RPG_RT.exe
VirusTotal:
https://www.virustotal.com/gui/file/893f41987626c05fcedff5eb780cfffe1397df7fa059df04f2459f1377ebdc1b/detection

jp_pf\RPG_RT.exe
VirusTotal:
https://www.virustotal.com/gui/file/a73206d58971c20d79fe6f5bad290c9d87d652f15b7755fc38cacc4f47c78dd9/detection


sample\*.*
This is a sample of how it is commonly used.



Link:
RPG Maker 2003 official store page
https://store.steampowered.com/app/362870/RPG_Maker_2003/

RPG Maker 2003 Patch EULA
https://steamcommunity.com/app/362870/discussions/0/541906348059148217/

RPG Maker 2003 Maniac Patch (The mod I created, and got many false positives)
https://bingshan1024.github.io/steam2003_maniacs/

